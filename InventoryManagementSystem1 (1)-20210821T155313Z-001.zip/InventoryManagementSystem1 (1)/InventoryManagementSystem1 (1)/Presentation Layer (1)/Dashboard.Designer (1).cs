﻿
namespace InventoryManagementSystem1.Presentation_Layer
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.productButton = new System.Windows.Forms.Button();
            this.categoryButton = new System.Windows.Forms.Button();
            this.employeeButton = new System.Windows.Forms.Button();
            this.paymentButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // productButton
            // 
            this.productButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.productButton.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productButton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.productButton.Location = new System.Drawing.Point(12, 102);
            this.productButton.Name = "productButton";
            this.productButton.Size = new System.Drawing.Size(126, 30);
            this.productButton.TabIndex = 8;
            this.productButton.Text = "Product_Item";
            this.productButton.UseVisualStyleBackColor = false;
            this.productButton.Click += new System.EventHandler(this.productButton_Click);
            // 
            // categoryButton
            // 
            this.categoryButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.categoryButton.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryButton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.categoryButton.Location = new System.Drawing.Point(12, 31);
            this.categoryButton.Name = "categoryButton";
            this.categoryButton.Size = new System.Drawing.Size(126, 35);
            this.categoryButton.TabIndex = 7;
            this.categoryButton.Text = "Category_Item";
            this.categoryButton.UseVisualStyleBackColor = false;
            this.categoryButton.Click += new System.EventHandler(this.categoryButton_Click);
            // 
            // employeeButton
            // 
            this.employeeButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.employeeButton.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeButton.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.employeeButton.Location = new System.Drawing.Point(12, 243);
            this.employeeButton.Name = "employeeButton";
            this.employeeButton.Size = new System.Drawing.Size(126, 31);
            this.employeeButton.TabIndex = 6;
            this.employeeButton.Text = "Employee_InFo";
            this.employeeButton.UseVisualStyleBackColor = false;
            this.employeeButton.Click += new System.EventHandler(this.employeeButton_Click);
            // 
            // paymentButton
            // 
            this.paymentButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.paymentButton.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentButton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.paymentButton.Location = new System.Drawing.Point(12, 171);
            this.paymentButton.Name = "paymentButton";
            this.paymentButton.Size = new System.Drawing.Size(126, 32);
            this.paymentButton.TabIndex = 5;
            this.paymentButton.Text = "Payment";
            this.paymentButton.UseVisualStyleBackColor = false;
            this.paymentButton.Click += new System.EventHandler(this.paymentButton_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.productButton);
            this.Controls.Add(this.categoryButton);
            this.Controls.Add(this.employeeButton);
            this.Controls.Add(this.paymentButton);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Dashboard_FormClosing);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button productButton;
        private System.Windows.Forms.Button categoryButton;
        private System.Windows.Forms.Button employeeButton;
        private System.Windows.Forms.Button paymentButton;
    }
}