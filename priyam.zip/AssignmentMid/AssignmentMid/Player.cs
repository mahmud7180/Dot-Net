﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentMid
{
    class Player:Employee
    {
        double rating;
        double wagePerMatch=1000;
        int noOfMatch;


        public double Rating
        {
            set { this.rating = value; }
            get { return this.rating; }
        }

        public double WagePerMatch
        {
            set { this.wagePerMatch = value; }
            get { return this.wagePerMatch; }
        }

        public int NoOfMatch
        {
            set { this.noOfMatch = value; }
            get { return this.noOfMatch; }
        }
       

        public void TotalEarn(int noOfMatch)
        {
            double TotalEarn = WagePerMatch * noOfMatch;
            Console.WriteLine("Total Earn : " + TotalEarn);
        }



    }
}
