﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentMid
{
    class Manager:Employee
    {
        double yearsOfExperience;

        public double YearOfExperience
        {
            set { this.yearsOfExperience = value; }
            get { return this.yearsOfExperience; }
        }




    }
}
